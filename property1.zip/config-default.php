<?php

$config['atk']['base_path']='./atk4/';
$config['dsn']='mysql://root:winserver@localhost/bhawani_property';


$config['url_postfix']='';
$config['url_prefix']='?page=';
