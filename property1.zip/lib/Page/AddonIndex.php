<?php
/**
 * Created by Vadym Radvansky
 * Date: 2/11/14 5:55 PM
 */
class Page_AddonIndex extends Page {
    function initMainPage() {

    }
}