<?php
class Form_Stacked extends Form {

    function init(){
        parent::init();
    }
    function defaultTemplate(){
        return array('form');
    }
}
