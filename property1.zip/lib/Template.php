<?php
// for compatibility extend this from SMlite
class Template extends GiTemplate {}
