<?php
class ApiCLI extends App_CLI {}
