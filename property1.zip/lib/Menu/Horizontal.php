<?php
class Menu_Horizontal extends Menu_Advanced {
    function defaultTemplate() {
        return array('menu/horizontal');
    }
}
