<?php
class Menu_Advanced_Title extends Menu_Advanced_Item {
}
