<?php
class Menu_Vertical extends Menu_Advanced {
    function defaultTemplate() {
        return array('menu/vertical');
    }
}
