<?php
class ApiWeb extends App_Web {}
