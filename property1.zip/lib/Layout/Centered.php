<?php
/**
 * Centered layout for showing a single form or message on the page
 */
class Layout_Centered extends Layout_Basic {


    function defaultTemplate() {
        return array('layout/centered');
    }

}
