<?php // vim:ts=4:sw=4:et:fdm=marker
/**
 * This is obsolete as of ATk 4.2.5.
 * Please use SQL_Model class instead.
 */
class Model_Table extends SQL_Model {}
