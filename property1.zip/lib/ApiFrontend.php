<?php
class ApiFrontend extends App_Frontend {}
