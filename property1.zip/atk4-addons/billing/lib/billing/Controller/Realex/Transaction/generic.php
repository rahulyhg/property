<?php
class billing_Controller_Realex_Transaction_generic extends ATK3_Controller{
	protected $model_name='billing_Model_Realex_Transaction_generic';
}
